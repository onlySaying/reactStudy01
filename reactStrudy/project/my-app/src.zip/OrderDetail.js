import React from 'react';

const OrderDetail = () => {
  const order = {
    status: '메뉴를 준비 중이에요',
    storeName: '대왕보쌈 하양점',
    menu: '보쌈족 + 소 (막국수 없음) 1개',
    discount: '3,000원 할인 받음',
    orderDate: '2024년 04월 10일 오전 07:51',
    orderNumber: '202404100751',
    items: [
      {
        name: '보쌈족 + 소 (막국수 없음)',
        quantity: 1,
        price: '31,000원',
        options: '단품 / 2-3인분 추가반찬 (31,000원)'
      }
    ],
    totalAmount: '31,000원',
    discountAmount: '3,000원',
    finalAmount: '28,000원',
    paymentMethod: '토스페이',
    contact: '010-1234-5678',
    address: '경상북도 경산시 하양읍금락3길 18-16 1층 (서부, 진주스 치킨V, 타치U)'
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2>주문상세</h2>
      <p>{order.status}</p>
      <h3>{order.storeName}</h3>
      <p>{order.menu}</p>
      <button style={{ padding: '5px 10px', border: '1px solid #ccc', borderRadius: '5px', backgroundColor: '#fff', marginBottom: '20px' }}>{order.discount}</button>
      <p>주문번호: {order.orderNumber}</p>
      <p>주문일시: {order.orderDate}</p>
      <hr />
      {order.items.map((item, index) => (
        <div key={index} style={{ marginBottom: '20px' }}>
          <h4>{item.name} {item.quantity}개</h4>
          <p>{item.options}</p>
          <p>{item.price}</p>
        </div>
      ))}
      <div style={{ marginBottom: '20px' }}>
        <h4>결제금액</h4>
        <p>주문금액: {order.totalAmount}</p>
        <p>할인금액: {order.discountAmount}</p>
        <p>총 결제금액: {order.finalAmount}</p>
        <p>결제방법: {order.paymentMethod}</p>
      </div>
      <div style={{ marginBottom: '20px' }}>
        <h4>연락처</h4>
        <p>{order.contact}</p>
        <h4>가게사장님께</h4>
        <p>{order.address}</p>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <button style={{ padding: '10px 20px', border: '1px solid #ff4d4d', borderRadius: '5px', backgroundColor: '#ff4d4d', color: '#fff' }}>주문내역 삭제</button>
        <button style={{ padding: '10px 20px', border: '1px solid #00c896', borderRadius: '5px', backgroundColor: '#00c896', color: '#fff' }}>같은 메뉴 담기</button>
      </div>
    </div>
  );
};

export default OrderDetail;