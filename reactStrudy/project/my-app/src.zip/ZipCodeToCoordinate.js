import React, { useState } from 'react';
import { getCoordinatesFromZipCode } from './geocode';
import MapComponent from './MapComponent';

const ZipCodeToCoordinates = () => {
  const [zipCode, setZipCode] = useState('');
  const [coordinates, setCoordinates] = useState({ latitude: 37.5665, longitude: 126.9780 }); // Default to Seoul

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const coords = await getCoordinatesFromZipCode(zipCode);
      setCoordinates(coords);
    } catch (err) {
      console.error(err);
      alert('Location not found');
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>
          Zip Code:
          <input
            type="text"
            value={zipCode}
            onChange={(e) => setZipCode(e.target.value)}
          />
        </label>
        <button type="submit">Get Coordinates</button>
      </form>
      <MapComponent position={[coordinates.latitude, coordinates.longitude]} />
    </div>
  );
};

export default ZipCodeToCoordinates;