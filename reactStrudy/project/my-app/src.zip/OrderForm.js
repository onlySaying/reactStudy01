import React, { useState } from 'react';

const OrderForm = () => {
  const [contact, setContact] = useState('010-1234-5678');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('토스페이');

  const handleContactChange = (e) => setContact(e.target.value);
  const handleNotesChange = (e) => setNotes(e.target.value);
  const handlePaymentChange = (e) => setPaymentMethod(e.target.value);

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2>주문하기</h2>
      <div style={{ marginBottom: '20px' }}>
        <input type="checkbox" id="pickup" />
        <label htmlFor="pickup"> 포장해서 직접 가져갈게요</label>
      </div>
      <div style={{ marginBottom: '20px' }}>
        <h3>가게주소</h3>
        <p>경상북도 경산시 하양읍금락3길 18-16 1층</p>
      </div>
      <div style={{ marginBottom: '20px' }}>
        <h3>내 연락처</h3>
        <input 
          type="text" 
          value={contact} 
          onChange={handleContactChange} 
          style={{ width: '100%', padding: '10px', fontSize: '16px' }} 
        />
      </div>
      <div style={{ marginBottom: '20px' }}>
        <h3>가게 사장님께</h3>
        <textarea 
          value={notes} 
          onChange={handleNotesChange} 
          style={{ width: '100%', padding: '10px', fontSize: '16px' }} 
          placeholder="요청사항 입력"
        />
        <p>일회용품X</p>
      </div>
      <div style={{ marginBottom: '20px' }}>
        <h3>결제수단</h3>
        <div>
          <input 
            type="radio" 
            id="card" 
            name="payment" 
            value="신용/체크카드" 
            checked={paymentMethod === '신용/체크카드'} 
            onChange={handlePaymentChange} 
          />
          <label htmlFor="card"> 신용/체크카드</label>
        </div>
        <div>
          <input 
            type="radio" 
            id="tosspay" 
            name="payment" 
            value="토스페이" 
            checked={paymentMethod === '토스페이'} 
            onChange={handlePaymentChange} 
          />
          <label htmlFor="tosspay"> 토스페이</label>
        </div>
        <div>
          <input 
            type="radio" 
            id="other" 
            name="payment" 
            value="기타 결제수단" 
            checked={paymentMethod === '기타 결제수단'} 
            onChange={handlePaymentChange} 
          />
          <label htmlFor="other"> 기타 결제수단</label>
        </div>
      </div>
      <div style={{ marginBottom: '20px' }}>
        <h3>결제금액</h3>
        <p>주문금액: 23,000원</p>
        <p>할인금액: -1,000원</p>
        <p>총 결제금액: 22,000원</p>
      </div>
      <button style={{ width: '100%', padding: '15px', backgroundColor: '#00c896', color: '#fff', fontSize: '18px', border: 'none', cursor: 'pointer' }}>
        22,000원 결제하기
      </button>
    </div>
  );
};

export default OrderForm;