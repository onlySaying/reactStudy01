export const getCoordinatesFromZipCode = async (zipCode) => {
    const response = await fetch(`https://nominatim.openstreetmap.org/search?postalcode=${zipCode}&country=South Korea&format=json&limit=1`);
    const data = await response.json();
    if (data.length > 0) {
      const { lat, lon } = data[0];
      return { latitude: lat, longitude: lon };
    } else {
      throw new Error('Location not found');
    }
  };