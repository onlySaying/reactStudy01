
import React from 'react';
import './App.css';
import KakaoMap from './KakaoMap';

function App() {
  return (
    <div className="App">
      <KakaoMap/>
    </div>
  );
}

export default App;